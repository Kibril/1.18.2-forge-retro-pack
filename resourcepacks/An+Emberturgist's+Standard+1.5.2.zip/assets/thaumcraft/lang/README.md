# thaumcraft-beta
Location for Thaumcraft beta testers to report problems and errors.

Suggestions should please go to the dedicated suggestions git at https://github.com/Azanor/thaumcraft-suggestions
